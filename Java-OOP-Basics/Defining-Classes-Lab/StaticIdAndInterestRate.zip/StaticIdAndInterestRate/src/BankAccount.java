
public class BankAccount {

    private final static double DEFAULT_INTEREST = 0.02;

    private static double rate  = DEFAULT_INTEREST;
    private static int bankAccountsCount;

    private int id;
    private double balance;

    public BankAccount() {
        this.id = ++bankAccountsCount;
    }

    public static void setInterest(double interest) {

        if (interest < 0) {
            System.out.println("Invalid amount");
            return;
        }

        rate = interest;
    }

    public void deposit(double amount) {

        if (amount < 0) {
            System.out.println("Invalid amount");
            return;
        }

        System.out.printf("Deposited %d to %s%n", (int)amount, this);
        this.balance += amount;
    }

    public double getInterest(int years) {

        return this.balance * rate * years;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
       return "ID" + this.id;
    }
}
