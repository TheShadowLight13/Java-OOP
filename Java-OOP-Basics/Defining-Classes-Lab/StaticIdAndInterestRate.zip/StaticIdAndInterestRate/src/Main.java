import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Main {

    public static void main(String[] args) throws IOException {

        HashMap<Integer, BankAccount> accounts = new HashMap<>();

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String input = reader.readLine();

        while (!input.equals("End")) {

            String[] data = input.split(" ");
            String command = data[0];

            switch (command) {
                case "Create":
                    createBankAccount(accounts);
                    break;
                case "Deposit":
                    depositInAccount(accounts, data);
                break;
                case "SetInterest":
                    setInterest(accounts, data);
                    break;
                case "GetInterest":
                    getInterestFromBankAccount(accounts, data);
                    break;
            }

            input = reader.readLine();
        }
    }

    private static void getInterestFromBankAccount(HashMap<Integer, BankAccount> accounts, String[] data) {

        int id = Integer.valueOf(data[1]);
        int years = Integer.valueOf(data[2]);

        if (!accounts.containsKey(id)) {
            System.out.println("Account does not exist");
            return;
        }

        System.out.printf("%.2f%n", accounts.get(id).getInterest(years));
    }

    private static void setInterest(HashMap<Integer, BankAccount> accounts, String[] data) {

        double interest = Double.valueOf(data[1]);
        BankAccount.setInterest(interest);
    }

    private static void depositInAccount(HashMap<Integer, BankAccount> accounts, String[] data) {

        int id = Integer.valueOf(data[1]);
        double amount = Integer.valueOf(data[2]);

        if (!accounts.containsKey(id)) {
            System.out.println("Account does not exist");
            return;
        }

        accounts.get(id).deposit(amount);
    }

    private static void createBankAccount(HashMap<Integer, BankAccount> accounts) {

        BankAccount bankAccount = new BankAccount();
        int id = bankAccount.getId();
        accounts.put(id, bankAccount);
        System.out.printf("Account %s created%n", bankAccount);
    }
}
